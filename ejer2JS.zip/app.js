function main () {
    let cadena;
    let patrones= ["AA","BCA","RTB","JT"];
    cadena=prompt("Introduce una cadena de caracteres: ");
    alert("Cadena introducida: "+ cadena);
   
} function encontrarPatron(cadena, patrones){
    let contador=0;
for (let c = 0; c < patrones.length; c++) {
    let patron = patrones[c];
    let index = cadena.toLowerCase().indexOf(patron.toLowerCase());
    while (index !== -1) {
        contador++;
        index = cadena.toLowerCase().indexOf(patron.toLowerCase(), index + 1);
    }
}
}
main();
encontrarPatron();
alert("Número de coincidencias: " + contador);
