function ejercicio3(){
let n;
let arrayintrod= [];
let contadorpares=0;
let contadorimpares=0;
let suma;
let media;
let mayor=0;
let menor=100000;
do {
    n=prompt("Introduce un número: ");
    if (n%2===0){
        contadorpares++;
    }if(n%2!==0){
        contadorimpares++;
    }
    if (n>mayor){
        mayor=n;
    }
    if (n<menor){
        menor=n;
    }
    if (n!==0){
    suma=suma+n;
    arrayintrod.push(n);
    }
}while(n>=1);
media=suma/arrayintrod.length;
alert("Lista de números introducidos: "+arrayintrod+ "Números pares: "+ contadorpares +  "Números impares: "+contadorimpares+ "Suma total: "+suma+  "Media: "+media+ "Mayor: "+ mayor+"Menor: "+menor);
}
ejercicio3();