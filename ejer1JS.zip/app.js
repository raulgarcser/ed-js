function main () {
    let cadena
    let contador
    let patrones= ["AA","BCA","RTB","JT"]
    cadena=prompt("Introduce una cadena de caracteres: ")
    alert("Cadena introducida: "+ cadena)
   
}
function encontrarPatron (cadena, patron){
   
    
}
